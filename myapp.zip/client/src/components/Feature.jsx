import React from 'react';



const Feature= ({feature}) =>(
  <div className="feat">
    <ul>
      <li className="feature">
        {feature}
      </li>
    </ul>
  </div>
)

export default Feature;