describe('Addition', ()=> {
  it('Testing is Jest is install correctly', () => {
    expect(2+2).toBe(4);
  })
})

